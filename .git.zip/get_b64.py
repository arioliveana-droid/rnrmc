import urllib.request
import base64
import os

req = urllib.request.Request(
    'https://crmmg.org.br/wp-content/themes/crmmg/images/logo-crmmg.png',
    headers={'User-Agent': 'Mozilla/5.0'}
)

try:
    with urllib.request.urlopen(req) as response:
        img_data = response.read()
        b64 = base64.b64encode(img_data).decode('utf-8')
        data_uri = f"data:image/png;base64,{b64}"
        
        with open('logo_b64.txt', 'w') as f:
            f.write(data_uri)
        print("Success")
except Exception as e:
    print(f"Error: {e}")
