import os
import glob

migrations_dir = r"c:\Users\PC\Desktop\NOVO DESESPERO\fondly-remembered-payments\supabase\migrations"
files = glob.glob(os.path.join(migrations_dir, "202*.sql"))
files.sort()

content = ""
for f in files:
    with open(f, 'r', encoding='utf-8') as file:
        content += f"-- Migration: {os.path.basename(f)}\n"
        content += file.read()
        content += "\n\n"

# Escreve o artefato com as migrações completas em markdown
artifact_path = r"C:\Users\PC\.gemini\antigravity\brain\d8283344-8d3e-4805-81f0-d5a5f10896c1\supabase_schema.md"
with open(artifact_path, 'w', encoding='utf-8') as out:
    out.write("# Supabase Database Setup\n\n")
    out.write("Copie e cole o código abaixo no **SQL Editor** da sua dashboard da Supabase e clique em RUN.\n\n")
    out.write("```sql\n")
    out.write(content)
    out.write("\n```\n")

print(f"Artifact created with {len(files)} migrations.")
