import fs from 'fs';
async function run() {
  try {
    const res = await fetch("https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/CRM-MG_logo.png/320px-CRM-MG_logo.png");
    if (!res.ok) {
       console.log("Failed to download from wikimedia");
       const res2 = await fetch("https://crmmg.org.br/wp-content/themes/crmmg/images/logo-crmmg.png");
       if (res2.ok) {
           const buffer = await res2.arrayBuffer();
           fs.writeFileSync("public/crm-mg-logo.png", Buffer.from(buffer));
           console.log("Downloaded from crmmg");
       } else {
           console.log("All failed");
       }
    } else {
       const buffer = await res.arrayBuffer();
       fs.writeFileSync("public/crm-mg-logo.png", Buffer.from(buffer));
       console.log("Downloaded from wikimedia");
    }
  } catch (e) {
    console.error(e);
  }
}
run();
